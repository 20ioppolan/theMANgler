#include <array>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <dirent.h>
#include <netdb.h>
#include <string>
#include <unistd.h>
#include <vector>

struct dir_t {
  bool access;
  std::string dir_name;
};

static std::vector<std::string> g_argv;
static std::vector<std::string> g_envp;

static std::time_t g_start_time;
static std::time_t g_end_time;
static bool g_running = true;

static uid_t g_uid;
static uid_t g_euid;
static gid_t g_gid;
static gid_t g_egid;

static std::array<dir_t, 12> g_dirs{
    dir_t{false, "/"},          dir_t{false, "/bin"},
    dir_t{false, "/home"},      dir_t{false, "/lib"},
    dir_t{false, "/lib64"},     dir_t{false, "/root"},
    dir_t{false, "/mnt"},       dir_t{false, "/sbin"},
    dir_t{false, "/usr/bin"},   dir_t{false, "/usr/sbin"},
    dir_t{false, "/usr/share"}, dir_t{false, "/etc"}};

static void sig_handler(int signum) {
  FILE *fp;
  char filename[128];
  struct tm *timenow;

  time_t now = time(NULL);
  timenow = gmtime(&now);

  strftime(filename, sizeof(filename), "/etc/INJECT%Y-%m-%d_%H:%M:%S", timenow);
  if (!(fp = fopen(filename, "w"))) {
    perror("fopen()");
    g_running = false;
    return;
  }

  g_running = false;
  g_end_time = std::time(nullptr);

  fprintf(fp, "Started: %s", std::asctime(std::localtime(&g_start_time)));
  fprintf(fp, "Ended: %s", std::asctime(std::localtime(&g_end_time)));
  fprintf(fp, "Ran for: %f s.\n", std::difftime(g_end_time, g_start_time));

  fprintf(fp, "Ran program with args:\n");
  for (auto &argv : g_argv) {
    fprintf(fp, "\t%s\n", argv.c_str());
  }
  fprintf(fp, "Environment Variables:\n");
  for (auto &envp : g_envp) {
    fprintf(fp, "\t%s\n", envp.c_str());
  }

  fprintf(fp, "User Info:\n");
  fprintf(fp, "\tuid=%d\n", g_uid);
  fprintf(fp, "\teuid=%d\n", g_euid);
  fprintf(fp, "\tgid=%d\n", g_gid);
  fprintf(fp, "\tegid=%d\n", g_egid);

  fprintf(fp, "Directory Access:\n");
  for (auto &dir : g_dirs) {
    fprintf(fp, "\t%s:%s\n", dir.dir_name.c_str(),
            dir.access ? "true" : "false");
  }

  fclose(fp);
}

void check_directories() {
  DIR *pdir = nullptr;

  for (auto &dir : g_dirs) {
    dir.access = true;
    if (!(pdir = opendir(dir.dir_name.c_str()))) {
      dir.access = false;
    }
    closedir(pdir);
  }
}

int main(int argc, char *argv[], char *envp[]) {
  g_start_time = std::time(nullptr);
  std::signal(SIGINT, sig_handler);
  std::signal(SIGTERM, sig_handler);

  g_uid = getuid();
  g_euid = geteuid();
  g_gid = getgid();
  g_egid = getegid();

  while (*argv) {
    g_argv.emplace_back(*argv);
    argv++;
  }

  while (*envp) {
    g_envp.emplace_back(*envp);
    envp++;
  }

  while (g_running) {
    check_directories();
    sleep(5);
  }

  return 0;
}